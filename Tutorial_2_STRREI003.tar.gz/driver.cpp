
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char* argv[])
{
	std::vector<std::string> menu_items;
	std::string filename;

	

	if(argc == 1)
		filename = "menu_1.txt";
	else
		filename = argv[1];
     
	std::ifstream in(filename);

	if(!in)
	{
		std::cout<< "Couldn't open file:" << filename << std::endl;
		return 1;
	}

	std::string line;
	std::string word;
	bool correctWord = true ;

	while(std::getline(in,line))
	{
		correctWord = true;
		menu_items.push_back(line);
	
		std::istringstream iss (line);
		
		while(correctWord){
			
			
			iss>>word;	
			
			if(isalpha(word[1])){		
				std:: cout << word << ' ';
			}else{
				std::cout<<'\n'<<'\t';
				std::cout<<"-";
				std::cout<<word;
				correctWord = false;
			}
				
		}

		iss>>word;
		std::cout<<'\n'<<'\t';
		std::cout<<"-";
		std::cout<<word;
		std::cout<<'\n';

	
	}

	in.close();

	std::cout << menu_items.size() << "Items on the menu" << std::endl;
	
}







